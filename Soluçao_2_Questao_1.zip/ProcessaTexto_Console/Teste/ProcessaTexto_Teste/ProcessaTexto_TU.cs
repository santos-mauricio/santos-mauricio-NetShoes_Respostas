﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ProcessaTexto_Console;


namespace ProcessaTexto_Teste
{
    [TestClass]
    public class ProcessaTexto_TU
    {
        [TestMethod]
        public void TesteBasico_VogalMinusculaNoFinal()
        {
            IStream oProc = new Stream("CaeabBacfi");

            oProc.AntesDeIniciarAProcura();

            char cAchou = new char();

            while (oProc.hasNext())
            {
                cAchou = oProc.getNext();

                if (cAchou != Char.MinValue)
                {
                    Console.WriteLine(cAchou);
                    break;
                }
            }

            Assert.AreEqual(cAchou, char.Parse("i"));
        }

        [TestMethod]
        public void TesteBasico_VogalMaiusculaNoFinal()
        {
            IStream oProc = new Stream("CaeabBacfI");

            oProc.lookingAll();

            Assert.AreEqual(oProc.Achou(), char.Parse("I"));
        }

        [TestMethod]
        public void TesteBasico_VogalMinusculaComAcentoNoFinal()
        {
            IStream oProc = new Stream("CaeabBacfì");

            oProc.lookingAll();

            Assert.AreEqual(oProc.Achou(), char.Parse("ì"));
        }

        [TestMethod]
        public void TesteBasico_VogalMaiusculaComAcentoNoFinal()
        {
            IStream oProc = new Stream("CaeabBacfÍ");

            oProc.lookingAll();

            Assert.AreEqual(oProc.Achou(), char.Parse("Í"));
        }

        [TestMethod]
        public void TesteBasico_VogalMinusculaNoComeco()
        {
            IStream oProc = new Stream("uCaeabBacf");

            oProc.lookingAll();

            Assert.AreEqual(oProc.Erro(), "Não foi encontrado o caracter seguindo as regras estabelecidas");
        }

        [TestMethod]
        public void TesteBasico_VogalMinusculaDepoisDeUmaConsoante()
        {
            IStream oProc = new Stream("TuCaeabBacfi");

            oProc.lookingAll();

            Assert.AreEqual(oProc.Achou(), char.Parse("u"));
        }

        [TestMethod]
        public void TesteBasico_VogalMinusculaComCaracterRepetidoNoFinal()
        {
            IStream oProc = new Stream("uCaeabBacfu");

            oProc.lookingAll();

            Assert.AreEqual(oProc.Erro(), "Não foi encontrado o caracter seguindo as regras estabelecidas");
        }

        [TestMethod]
        public void TesteBasico_VogalMaiusculaComAcentoComCaracterRepetidoNoFinalMinusculaSemAcento()
        {
            IStream oProc = new Stream("ÙCaeabBacfu");

            oProc.lookingAll();

            Assert.AreEqual(oProc.Erro(), "Não foi encontrado o caracter seguindo as regras estabelecidas");
        }

        [TestMethod]
        public void TesteBasico_TextoVazio()
        {
            IStream oProc = new Stream("");

            oProc.lookingAll();

            Assert.AreEqual(oProc.Erro(), "Não foi encontrado o caracter seguindo as regras estabelecidas");
        }


        [TestMethod]
        public void TesteBasico_TextoComEspacosEmBranco()
        {
            IStream oProc = new Stream("           ");

            oProc.lookingAll();

            Assert.AreEqual(oProc.Erro(), "Não foi encontrado o caracter seguindo as regras estabelecidas");
        }

        [TestMethod]
        public void TesteBasico_TextoComEspacosEmBrancoEUmaVogal()
        {
            IStream oProc = new Stream("     e      ");

            oProc.lookingAll();

            Assert.AreEqual(oProc.Erro(), "Não foi encontrado o caracter seguindo as regras estabelecidas");
        }

        [TestMethod]
        public void TesteBasico_TextoComEspacosEmBrancoEUmaConsoanteEUmaVogal()
        {
            IStream oProc = new Stream("     ze      ");

            oProc.lookingAll();

            Assert.AreEqual(oProc.Achou(), char.Parse("e"));
        }

        [TestMethod]
        public void TesteBasico_TextoComEspacosEmBrancoEDuasVogais()
        {
            IStream oProc = new Stream("     ie      ");

            oProc.lookingAll();

            Assert.AreEqual(oProc.Erro(), "Não foi encontrado o caracter seguindo as regras estabelecidas");
        }

        [TestMethod]
        public void TesteBasico_TextoComEspacosEmBrancoEDuasConsoantes()
        {
            IStream oProc = new Stream("     mb      ");

            oProc.lookingAll();

            Assert.AreEqual(oProc.Erro(), "Não foi encontrado o caracter seguindo as regras estabelecidas");
        }

        [TestMethod]
        public void TesteBasico_TextoComEspacosUmCaracterEspecialEUmaVogal()
        {
            IStream oProc = new Stream("     $a      ");

            oProc.lookingAll();

            Assert.AreEqual(oProc.Erro(), "Não foi encontrado o caracter seguindo as regras estabelecidas");
        }

        [TestMethod]
        public void TesteBasico_TextoComEspacosEntreUmaConsoanteEUmaVogal()
        {
            IStream oProc = new Stream("b a");

            oProc.lookingAll();

            Assert.AreEqual(oProc.Erro(), "Não foi encontrado o caracter seguindo as regras estabelecidas");
        }

        [TestMethod]
        public void TesteBasico_TextoComUmaConsoanteEUmaVogal()
        {
            IStream oProc = new Stream("ba");

            oProc.lookingAll();

            Assert.AreEqual(oProc.Achou(), char.Parse("a"));
        }

        [TestMethod]
        public void TesteBasico_TextoComUmNumeroEUmaVogal()
        {
            IStream oProc = new Stream("5a");

            oProc.lookingAll();

            Assert.AreEqual(oProc.Erro(), "Não foi encontrado o caracter seguindo as regras estabelecidas");
        }

        [TestMethod]
        public void TesteBasico_TextoComDuasVogaisPossiveis()
        {
            IStream oProc = new Stream("Qthabecafix");

            oProc.lookingAll();

            Assert.AreEqual(oProc.Achou(), char.Parse("e"));
        }

        [TestMethod]
        public void TesteBasico_TextoComEspacoEntreDuasVogaisPossiveis()
        {
            IStream oProc = new Stream(" QthabE cafix ");

            oProc.lookingAll();

            Assert.AreEqual(oProc.Achou(), char.Parse("E"));
        }
    }
}
