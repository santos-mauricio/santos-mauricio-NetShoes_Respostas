﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ProcessaTexto_Console
{
    public interface IStream
    {
        char getNext();
        bool hasNext();
        void AntesDeIniciarAProcura();
        string Erro();
        void lookingAll();
        char Achou();
        void goFirst();
    }

}
