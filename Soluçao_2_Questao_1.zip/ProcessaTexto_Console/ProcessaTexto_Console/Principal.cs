﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProcessaTexto_Console
{
    class Principal
    {
        static void Main(string[] args)
        {
            IStream oProc = new Stream("iCaeabBacfis");
            oProc.AntesDeIniciarAProcura();

            char cAchou = new char();

            while (oProc.hasNext())
            {
                cAchou = oProc.getNext();

                if (cAchou != Char.MinValue)
                {
                    Console.WriteLine(cAchou);
                    break;
                }
            }

            if (cAchou == Char.MinValue)
            {
                Console.WriteLine(oProc.Erro());
            }
            Console.ReadLine();
        }
    }
}
