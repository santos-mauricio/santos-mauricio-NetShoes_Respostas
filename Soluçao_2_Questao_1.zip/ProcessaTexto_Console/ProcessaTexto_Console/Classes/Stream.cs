﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProcessaTexto_Console
{
    public class Stream : IStream
    {
        private int iPosicao = -1;
        private string sCaracterQueSeRepete = "";
        private string sAcuTexto = "";
        private bool bPreparouAExecucao = false;

        public string sErro;
        public char cAchou;

        public Stream(string Texto)
        {
            this.Texto = Texto;
            this.iPosicao = -1;
            this.sErro = "";
            this.cAchou = new Char();
            this.sCaracterQueSeRepete = "";
            this.bPreparouAExecucao = false;
        }

        /// <summary>
        /// Metodo prepara o objeto para o processamento
        /// </summary>
        public void AntesDeIniciarAProcura()
        {
            // Esse metodo prepara a execução da classe para que o processo seja mais rapido
            this.sAcuTexto = RemoveAcento(this.Texto.ToLower()); // Converte a string para letras minusculas para ficar mais fácil a comparação
            this.bPreparouAExecucao = true;

        }

        /// <summary>
        /// Propriedade Texto, informa ou retorna o texto que será processado
        /// </summary>
        public string Texto { get; set; }

        /// <summary>
        /// Metodo posiciona a procura para o inicio do texto
        /// </summary>
        public void goFirst()
        {
            iPosicao = -1;
        }

        /// <summary>
        /// Metodo verifica se tem mais texto para ser processado ou não
        /// </summary>
        public bool hasNext()
        {
            if (!bPreparouAExecucao)
            {
                throw new System.ArgumentException("Favor executar o metodo AntesDeIniciarAProcura(), antes de iniciar a procura.");
            }
            bool bHasNext = iPosicao + 1 < Texto.Length;

            if (!bHasNext && this.cAchou == Char.MinValue)
            {
                this.sErro = "Não foi encontrado o caracter seguindo as regras estabelecidas";
            }
            return bHasNext;
        }


        /// <summary>
        /// Metodo verifica a posicao seguinte e caso encontre a vogal dentro das regras estabelecida retorna o valor na propriedade cAchou
        /// </summary>
        public char getNext()
        {
            this.iPosicao++;
            this.cAchou = firstChar(this.sAcuTexto);

            return this.cAchou;
        }

        /// <summary>
        /// Metodo processa toda a string
        /// </summary>
        public void lookingAll()
        {
            AntesDeIniciarAProcura();
            goFirst();
            while (this.hasNext())
            {
                this.getNext();

                if (this.cAchou != Char.MinValue)
                {
                    break;
                }
            }
        }

        /// <summary>
        /// Metodo retorna a vogal seguindo as regras definidas
        /// </summary>
        /// <param name="sTexto">Texto que será processado</param>
        /// <returns>Retorna a vogal encontrada dentro dos parametros estabelecido</returns>
        private char firstChar(string sTexto)
        {


            string sVogal = "aeiou"; // Lista de vogais
            string sConsoante = "bcdfghjklmnpqrstvxyz"; // Lista de consoantes


            // Seleciona o carater da posição i
            string c = sTexto.Substring(this.iPosicao, 1);

            // Verifica se o caracter encontrado está na lista dos caracteres repetidos
            if (!sCaracterQueSeRepete.Contains(c))
            {
                // Verifica se o caracter se repete
                if (ContaChars(sTexto, c) == 1)
                {
                    // Verifica se o caracter da posição i é uma consoante e que o caracter anterior seja uma vogal
                    if (this.iPosicao>0 && sVogal.Contains(c) && sConsoante.Contains(sTexto.Substring(this.iPosicao - 1, 1)))
                    {
                        // Remove o caracter da posição para ver se ele existe em outros lugares
                        return char.Parse(this.Texto.Substring(this.iPosicao, 1));  // Retorna o caracter Original
                    }

                }
                else
                {
                    // Memoriza o caracter encontrado com mais de uma ocorrencia
                    sCaracterQueSeRepete = sCaracterQueSeRepete + c;
                }

            }


            return new char();


        }

        /// <summary>
        /// Metodo conta a quantidade de vezes que o caracter se repete na string
        /// </summary>
        /// <param name="sTexto">Texto que será processado</param>
        /// <param name="cProcurado">Caracter procurado</param>
        /// <returns>
        /// Quantidade de vezes que o caracter procurado é encontrado
        /// </returns>
        private int ContaChars(string sTexto, string cProcurado)
        {
            int iCnt = 0;

            // Varre a string inteira procurando pelo caracter procurado
            for (int i = 0; i < sTexto.Length; i++)
            {
                // Memoriza o caracter encontrado na posição i
                string c = sTexto.Substring(i, 1);

                // Compara com o caracter encontrado com o caracter procurado 
                if (c == cProcurado)
                {
                    // Conta todas as vezes que encontrar
                    iCnt++;
                }
            }

            // Retorna a quantidade de vezes que o caracter procurado foi encontrado
            return iCnt;

        }

        /// <summary>
        /// Metodo remove os acentos da palavra
        /// </summary>
        /// <param name="sTexto">Texto que será processado</param>
        /// <returns>
        /// Retorna o texto sem acentos
        /// </returns>
        private string RemoveAcento(string sTexto)
        {
            string sTextoSemAcento = "";
            string sVogalComAcento = "àáãâéèêíìîóòõôúùû"; // Lista de vogais com acento
            string sVogalSemAcento = "aaaaeeeiiioooouuu"; // Lista de vogais sem acento

            for (int i=0; i<sTexto.Length; i++)
            {
                string c = sTexto.Substring(i, 1);
                int p = sVogalComAcento.IndexOf(c);

                if (p>0)
                {
                    sTextoSemAcento = sTextoSemAcento + sVogalSemAcento.Substring(p, 1);
                } else
                {
                    sTextoSemAcento = sTextoSemAcento + c;
                }

            }


            return sTextoSemAcento;
        }

        /// <summary>
        /// Metodo retorna um erro caso nenhuma vogal tenha sido encontrada seguindo as regras estabelecidas
        /// </summary>
        public string Erro()
        {
            return this.sErro;
        }

        /// <summary>
        /// Metodo retorna o caracter encontrado seguindo as regras estabelecidas 
        /// </summary>
        public char Achou()
        {
            return this.cAchou;
        }

    }
}
