﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication1.Classes
{
    public class NotaFiscal_Itens
    {

        public NotaFiscal_Itens(string CodProd, string NomeProd, int QtdVendida, decimal VlrUnitario, decimal PIS, decimal COFINS)
        {
            this.CodProd = CodProd;
            this.NomeProd = NomeProd;
            this.QtdVendida = QtdVendida;
            this.VlrUnitario = VlrUnitario;
            this.PIS = PIS;
            this.COFINS = COFINS;

        }
        public string CodProd { get; set; }
        public string NomeProd { get; set; }
        public int QtdVendida { get; set; }
        public decimal VlrUnitario { get; set; }
        public decimal PIS { get; set; }
        public decimal COFINS { get; set; }


    }
}
