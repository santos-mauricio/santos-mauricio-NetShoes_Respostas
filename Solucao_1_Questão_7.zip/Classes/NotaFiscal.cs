﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace WindowsFormsApplication1.Classes
{
    public class NotaFiscal
    {
        private string sEstadoOrigem="";
        private string sEstadoDestino="";

        public List<Classes.NotaFiscal_Itens> Itens = new List<Classes.NotaFiscal_Itens>();

        public NotaFiscal()
        {
            this.Desconto = 0;
        }

        public int NumNF { get; set; }
        public decimal TotalNF { get; set; }
        public DateTime DtEmissao { get; set; }
        public int CodNatOper { get; set; }
        public string Nome { get; set; }
        public string Endereco { get; set; }
        public string Bairro { get; set; }
        public string Cidade { get; set; }
        public string CEP { get; set; }
        public decimal ValorICMS { get; set; }
        public decimal AliqICMS { get; set; }
        public decimal Desconto { get; set; }

        public int CFOP { get; set; }
        

        public string EstadoOrigem
        {
            get { return sEstadoOrigem; }
            set { sEstadoOrigem = value.Trim().ToUpper(); AjustaCFOP_Pelo_Estado(); }
        }

        public string EstadoDestino
        {
            get { return this.sEstadoDestino; }
            set { this.sEstadoDestino = value.Trim().ToUpper(); AjustaCFOP_Pelo_Estado(); AjustaDesconto_Pelo_EstadoDestino(); }
        }

        private void AjustaCFOP_Pelo_Estado()
        {
            if (this.sEstadoOrigem.Equals("SP") && this.sEstadoDestino.Equals("RO"))
            {
                this.CFOP = 6006;
            }

        }

        private void AjustaDesconto_Pelo_EstadoDestino()
        {
            const string sEstadoSudeste = "SP;RJ;MG;ES";

            if (sEstadoSudeste.Contains(this.sEstadoDestino))
            {
                this.Desconto = 10;
            }
        }

        public bool GravaNotaFiscalEmXml(string sNomeArq)
        {
            bool bGravou = false;
            
            XmlSerializer xmlSer = new XmlSerializer(typeof(DataSet));
            DataSet dts = new DataSet("NotaFiscal");
            DataTable NF = dtNF();
            DataTable NF_Itens = dtNF_Itens();

            dts.Tables.Add(NF);
            dts.Tables.Add(NF_Itens);

            // Gravando os dados da NF
            try
            {
                DataRow rwNF = NF.NewRow();
                rwNF["NumNF"] = this.NumNF;
                rwNF["CFOP"] = this.CFOP;
                rwNF["TotalNF"] = this.TotalNF;
                rwNF["DtEmissao"] = this.DtEmissao;
                rwNF["ValorICMS"] = this.ValorICMS;
                rwNF["AliqICMS"] = this.AliqICMS;
                rwNF["Desconto"] = this.Desconto;

                NF.Rows.Add(rwNF);

            }
            catch (Exception e)
            {
                throw e;
            }

            // Gravando os itens da NF
            try
            {

                foreach (var item in this.Itens)
                {
                    DataRow rwItem = NF_Itens.NewRow();
                    rwItem["CodProd"] = item.CodProd;
                    rwItem["NomeProd"] = item.NomeProd;
                    rwItem["QtdVendida"] = item.QtdVendida;
                    rwItem["VlrUnitario"] = item.VlrUnitario;
                    rwItem["Brinde"] = item.getBrinde();
                    rwItem["IPI"] = item.IPI;
                    rwItem["VlrIPI"] = item.VlrIPI;
                    rwItem["PIS"] = item.PIS;
                    rwItem["COFINS"] = item.COFINS;
                    rwItem["SubTotal"] = item.QtdVendida * item.VlrUnitario;

                    NF_Itens.Rows.Add(rwItem);

                    this.TotalNF = this.TotalNF + (item.QtdVendida * item.VlrUnitario);
                }

            }
            catch (Exception e)
            {
                throw e;
            }


            // Gravando o arquivo
            try
            {
                dts.WriteXml(sNomeArq, XmlWriteMode.WriteSchema);
                return true;

            }
            catch (Exception e)
            {
                throw e;
            }
            

            return bGravou;
        }


        public bool ValidaCamposXML(DataSet dtsXml)
        {
            DataSet dtsOriginal = new DataSet("NotaFiscal");
            DataTable NF = dtNF();
            DataTable NF_Itens = dtNF_Itens();

            dtsOriginal.Tables.Add(NF);
            dtsOriginal.Tables.Add(NF_Itens);

            // Verifica se os dois Datasets possui a mesma quantidade de tabelas
            if (dtsXml.Tables.Count != dtsOriginal.Tables.Count )
            {
                return false;
            }

            // Verica se a quantidade de colunas da Nota Fiscal é diferente
            if (dtsXml.Tables[0].Columns.Count != dtsOriginal.Tables[0].Columns.Count)
            {
                return false;
            }


            // Compara estruturas
            for (int t=0; t<dtsOriginal.Tables.Count;t++)
            {
                // Verica se o nome das tabelas são iguais
                if (!dtsOriginal.Tables[t].TableName.Equals(dtsXml.Tables[t].TableName))
                {
                    return false;
                }
                for (int c=0; c<dtsOriginal.Tables[t].Columns.Count; c++)
                {
                    if (!dtsOriginal.Tables[t].Columns[c].ColumnName.Equals(dtsXml.Tables[t].Columns[c].ColumnName))
                    {
                        return false;
                    }

                    if (!dtsOriginal.Tables[t].Columns[c].DataType.Equals(dtsXml.Tables[t].Columns[c].DataType))
                    {
                        return false;
                    }
                }
            }


            return true;
        }

        private DataTable dtNF()
        {
            DataTable NF = new DataTable("NF");
            NF.Columns.Add("NumNF", typeof(int));
            NF.Columns.Add("CFOP", typeof(int));
            NF.Columns.Add("TotalNF", typeof(decimal));
            NF.Columns.Add("DtEmissao", typeof(DateTime));
            NF.Columns.Add("ValorICMS", typeof(decimal));
            NF.Columns.Add("AliqICMS", typeof(decimal));
            NF.Columns.Add("Desconto", typeof(decimal));
            return NF;
        }

        private DataTable dtNF_Itens()
        {
            DataTable NF_Itens = new DataTable("NF_Itens");
            NF_Itens.Columns.Add("CodProd");
            NF_Itens.Columns.Add("NomeProd");
            NF_Itens.Columns.Add("QtdVendida", typeof(int));
            NF_Itens.Columns.Add("VlrUnitario", typeof(decimal));
            NF_Itens.Columns.Add("Brinde", typeof(bool));
            NF_Itens.Columns.Add("IPI", typeof(decimal));
            NF_Itens.Columns.Add("VlrIPI", typeof(decimal));
            NF_Itens.Columns.Add("PIS", typeof(decimal));
            NF_Itens.Columns.Add("COFINS", typeof(decimal));
            NF_Itens.Columns.Add("SubTotal", typeof(decimal));
            return NF_Itens;
        }

    }
}
