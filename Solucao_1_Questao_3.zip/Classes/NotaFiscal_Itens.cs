﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication1.Classes
{
    public class NotaFiscal_Itens
    {
        bool bBrinde;

        public NotaFiscal_Itens(string CodProd, string NomeProd, int QtdVendida, decimal VlrUnitario, bool Brinde, decimal PIS, decimal COFINS)
        {
            this.CodProd = CodProd;
            this.NomeProd = NomeProd;
            this.QtdVendida = QtdVendida;
            this.VlrUnitario = VlrUnitario;
            this.IPI = IPI;
            this.PIS = PIS;
            this.COFINS = COFINS;

            setBrinde(Brinde);
        }
        public string CodProd { get; set; }
        public string NomeProd { get; set; }
        public int QtdVendida { get; set; }
        public decimal VlrUnitario { get; set; }
        public decimal IPI { get; protected set; }
        public decimal PIS { get; set; }
        public decimal COFINS { get; set; }
        public decimal VlrIPI { get; protected set; }
        public void setBrinde(bool Brinde)
        {
            this.bBrinde = Brinde;

            if (bBrinde)
            {
                this.IPI = 0;
            } else
            {
                this.IPI = 10;
            }

            this.VlrIPI = (this.VlrUnitario * this.IPI) / 100;

        }
        public bool getBrinde()
        {
            return this.bBrinde;
        }


    }
}
