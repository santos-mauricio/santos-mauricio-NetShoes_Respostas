﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.IO;
using System.Xml.Serialization;

namespace WindowsFormsApplication1.Classes
{
    public class GravaNoBanco
    {
        public static bool GravaNF(string sNomeArqXml)
        {
            Classes.NotaFiscal notaFiscal = new Classes.NotaFiscal();
            DataSet dtsNF = new DataSet();

            // Carrega o arquivo no dataset
            try
            {
                dtsNF.ReadXml(sNomeArqXml, XmlReadMode.ReadSchema);
            }
            catch (Exception e)
            {

                throw e;
            }

            if (!notaFiscal.ValidaCamposXML(dtsNF))
            {
                throw new System.ArgumentException("Estrutura do XML é inválida.");
            }

            string sNF_Xml = DataSet_To_Xml(dtsNF, "NF");
            string sNF_Itens_Xml = DataSet_To_Xml(dtsNF, "NF_Itens");

            Chama_P_NOTA_FISCAL(sNF_Xml);
            Chama_P_NOTA_FISCAL_ITEM(sNF_Itens_Xml);

            return true;

        }


        private static string DataSet_To_Xml(DataSet dts, string sNomeTb)
        {
            string sXml = "";


            DataSet dtsNF = new DataSet();
            DataTable tb = dts.Tables[sNomeTb].Copy();
            dtsNF.Tables.Add(tb);

            using (MemoryStream oMemoryStream = new MemoryStream())
            {
                using (TextWriter oStreamWriter = new StreamWriter(oMemoryStream))
                {
                    XmlSerializer oSerializer = new XmlSerializer(typeof(DataSet));
                    try
                    {
                        oSerializer.Serialize(oStreamWriter, dtsNF);
                        sXml = Encoding.UTF8.GetString(oMemoryStream.ToArray());
                    }
                    catch (Exception e)
                    {

                        throw e;
                    }
                }
            }


            return sXml;
        }


        private static void Chama_P_NOTA_FISCAL_ITEM(string sNF_Itens_Xml)
        {
            throw new NotImplementedException();
        }

        private static void Chama_P_NOTA_FISCAL(string sNF_Xml)
        {
            throw new NotImplementedException();
        }

    }
}

