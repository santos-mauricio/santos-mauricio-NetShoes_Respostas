﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace WindowsFormsApplication1.Classes
{
    public class NotaFiscal
    {
        public List<Classes.NotaFiscal_Itens> Itens = new List<Classes.NotaFiscal_Itens>();
        public int NumNF { get; set; }
        public decimal TotalNF { get; set; }
        public DateTime DtEmissao { get; set; }
        public int CodNatOper { get; set; }
        public string Nome { get; set; }
        public string Endereco { get; set; }
        public string Bairro { get; set; }
        public string Cidade { get; set; }
        public string Estado { get; set; }
        public string CEP { get; set; }
        public decimal ValorICMS { get; set; }
        public decimal AliqICMS { get; set; }

        public bool GravaNotaFiscalEmXml(string sNomeArq)
        {
            bool bGravou = false;
            
            XmlSerializer xmlSer = new XmlSerializer(typeof(DataSet));
            DataSet dts = new DataSet("NotaFiscal");
            DataTable NF = new DataTable("NF");
            DataTable NF_Itens = new DataTable("NF_Itens");

            NF.Columns.Add("NumNF", typeof(int));
            NF.Columns.Add("TotalNF", typeof(decimal));
            NF.Columns.Add("DtEmissao", typeof(DateTime));
            NF.Columns.Add("ValorICMS", typeof(decimal));
            NF.Columns.Add("AliqICMS", typeof(decimal));
            dts.Tables.Add(NF);

            NF_Itens.Columns.Add("CodProd");
            NF_Itens.Columns.Add("NomeProd");
            NF_Itens.Columns.Add("QtdVendida",typeof(int));
            NF_Itens.Columns.Add("VlrUnitario",typeof(decimal));
            NF_Itens.Columns.Add("IPI", typeof(decimal));
            NF_Itens.Columns.Add("PIS", typeof(decimal));
            NF_Itens.Columns.Add("COFINS", typeof(decimal));
            NF_Itens.Columns.Add("SubTotal", typeof(decimal));
            dts.Tables.Add(NF_Itens);

            // Gravando os dados da NF
            try
            {
                DataRow rwNF = NF.NewRow();
                rwNF["NumNF"] = this.NumNF;
                rwNF["TotalNF"] = this.TotalNF;
                rwNF["DtEmissao"] = this.DtEmissao;
                rwNF["ValorICMS"] = this.ValorICMS;
                rwNF["AliqICMS"] = this.AliqICMS;

                NF.Rows.Add(rwNF);

            }
            catch (Exception e)
            {
                throw e;
            }

            // Gravando os itens da NF
            try
            {

                foreach (var item in this.Itens)
                {
                    DataRow rwItem = NF_Itens.NewRow();
                    rwItem["CodProd"] = item.CodProd;
                    rwItem["NomeProd"] = item.NomeProd;
                    rwItem["QtdVendida"] = item.QtdVendida;
                    rwItem["VlrUnitario"] = item.VlrUnitario;
                    rwItem["IPI"] = item.IPI;
                    rwItem["PIS"] = item.PIS;
                    rwItem["COFINS"] = item.COFINS;
                    rwItem["SubTotal"] = item.QtdVendida * item.VlrUnitario;

                    NF_Itens.Rows.Add(rwItem);

                    this.TotalNF = this.TotalNF + (item.QtdVendida * item.VlrUnitario);
                }

            }
            catch (Exception e)
            {
                throw e;
            }


            // Gravando o arquivo
            try
            {
                TextWriter txtFile = new StreamWriter(sNomeArq);
                xmlSer.Serialize(txtFile, dts);
                txtFile.Close();
                return true;

            }
            catch (Exception e)
            {
                throw e;
            }
            

            return bGravou;
        }

    }
}
