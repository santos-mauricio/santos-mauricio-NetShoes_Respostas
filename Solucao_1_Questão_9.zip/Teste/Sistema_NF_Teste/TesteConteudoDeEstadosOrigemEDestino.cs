﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Sistema_NF.Classes;

namespace Sistema_NF_Teste
{
    [TestClass]
    public class TesteConteudoDeEstadosOrigemEDestino
    {
        [TestMethod]
        public void EstadoOrigem_SP_Estado_Destino_RO()
        {
            NotaFiscal notaFiscal = new NotaFiscal(1001, 1000, DateTime.Now, 3068, "SP", "RO", 10, 100);

            Assert.AreEqual(notaFiscal.CFOP, 6006);
        }

        [TestMethod]
        public void EstadoOrigem_Sp_Estado_Destino_ro()
        {
            NotaFiscal notaFiscal = new NotaFiscal(1001, 1000, DateTime.Now, 3068, "Sp", "ro", 10, 100);

            Assert.AreEqual(notaFiscal.CFOP, 6006);
        }

        [TestMethod]
        public void EstadoOrigem_Sp_Estado_Destino_ro_ComEspacos()
        {
            NotaFiscal notaFiscal = new NotaFiscal(1001, 1000, DateTime.Now, 3068, " Sp ", " ro ", 10, 100);

            Assert.AreEqual(notaFiscal.CFOP, 6006);
        }

        [TestMethod]
        public void EstadoOrigem_Sp_Estado_Destino_mg_ComEspacos()
        {
            NotaFiscal notaFiscal = new NotaFiscal(1001, 1000, DateTime.Now, 3068, " Sp ", " mg ", 10, 100);

            Assert.AreEqual(notaFiscal.CFOP, 0);
        }

        [TestMethod]
        public void Estado_Destino_MG_ComEspacos()
        {
            NotaFiscal notaFiscal = new NotaFiscal(1001, 1000, DateTime.Now, 3068, " Sp ", " mg ", 10, 100);

            Assert.AreEqual(notaFiscal.Desconto, 10);
        }

        [TestMethod]
        public void Estado_Destino_SP()
        {
            NotaFiscal notaFiscal = new NotaFiscal(1001, 1000, DateTime.Now, 3068, " Sp ", "SP", 10, 100);

            Assert.AreEqual(notaFiscal.Desconto, 10);
        }

        [TestMethod]
        public void Estado_Destino_RJ()
        {
            NotaFiscal notaFiscal = new NotaFiscal(1001, 1000, DateTime.Now, 3068, " Sp ", "RJ", 10, 100);

            Assert.AreEqual(notaFiscal.Desconto, 10);
        }

        [TestMethod]
        public void Estado_Destino_ES()
        {
            NotaFiscal notaFiscal = new NotaFiscal(1001, 1000, DateTime.Now, 3068, " Sp ", "ES", 10, 100);

            Assert.AreEqual(notaFiscal.Desconto, 10);
        }

        [TestMethod]
        public void Estado_Destino_RS()
        {
            NotaFiscal notaFiscal = new NotaFiscal(1001, 1000, DateTime.Now, 3068, " Sp ", "RS", 10, 100);

            Assert.AreEqual(notaFiscal.Desconto, 0);
        }
    }
}
