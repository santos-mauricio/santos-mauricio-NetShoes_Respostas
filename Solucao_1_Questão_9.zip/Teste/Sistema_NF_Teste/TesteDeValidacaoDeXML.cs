﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Sistema_NF.Classes;
using System.Data;
using System.IO;

namespace Sistema_NF_Teste
{
    [TestClass]
    public class TesteDeValidacaoDeXML
    {
        string sPathXml = (Directory.GetCurrentDirectory() + @"\XMLs\");

        [TestMethod]
        public void ArqXML_Ok()
        {
            NotaFiscal notaFiscal = new NotaFiscal();
            DataSet dts = new DataSet();
            dts.ReadXml(sPathXml + "ArqOk.XML");

            Assert.AreEqual( notaFiscal.ValidaCamposXML(dts), true );
        }

        [TestMethod]
        public void ArqXML_FaltandoUmCampoNaNF()
        {
            NotaFiscal notaFiscal = new NotaFiscal();
            DataSet dts = new DataSet();
            dts.ReadXml(sPathXml + "FaltandoUmCampoNaNF.XML");

            Assert.AreEqual(notaFiscal.ValidaCamposXML(dts), false);
        }

        [TestMethod]
        public void ArqXML_FaltandoUmCampoNaNF_Itens()
        {
            NotaFiscal notaFiscal = new NotaFiscal();
            DataSet dts = new DataSet();
            dts.ReadXml(sPathXml + "FaltandoUmCampoNaNF_Itens.XML");

            Assert.AreEqual(notaFiscal.ValidaCamposXML(dts), false);
        }

        [TestMethod]
        public void ArqXML_ComUmaColunaNaNF_Itens_ComNomeDiferenteDoEsperado()
        {
            NotaFiscal notaFiscal = new NotaFiscal();
            DataSet dts = new DataSet();
            dts.ReadXml(sPathXml + "ComUmaColunaNaNF_Itens_ComNomeDiferenteDoEsperado.XML");

            Assert.AreEqual(notaFiscal.ValidaCamposXML(dts), false);
        }

        [TestMethod]
        public void ArqXML_ComUmaColunaNaNF_Itens_ComTipoDiferenteDoEsperado()
        {
            NotaFiscal notaFiscal = new NotaFiscal();
            DataSet dts = new DataSet();
            dts.ReadXml(sPathXml + "ComUmaColunaNaNF_Itens_ComTipoDiferenteDoEsperado.XML");

            Assert.AreEqual(notaFiscal.ValidaCamposXML(dts), false);
        }

        [TestMethod]
        public void ArqXML_ComUmaColunaNaNF_Itens_MaisDoEsperado()
        {
            NotaFiscal notaFiscal = new NotaFiscal();
            DataSet dts = new DataSet();
            dts.ReadXml(sPathXml + "ComUmaColunaNaNF_Itens_MaisDoEsperado.XML");

            Assert.AreEqual(notaFiscal.ValidaCamposXML(dts), false);
        }
    }
}
