
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[sp_sel_retorna_totais_da_nf]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].sp_sel_retorna_totais_da_nf


create procedure dbo.sp_sel_retorna_totais_da_nf
as 
	select	nf.CFOP, 
			Sum(nf.Valor_BaseICMS )		as TotalBase_ICM, 
			Sum(nf.ICMS)				as Total_ICMS, 
			Sum(item.Valor_BaseIPI)		as TotalBase_IPI, 
			Sum(item.IPI)				as Total_IPI 
	from	dbo.TbNF		as nf	join
			dbo.TbNF_Item	as item	on	nf.NumNF = item.NumNF
	group by nf.CFOP
	
go


